// import parser??
import bfk.BFParser;

public class Main {
  public static void main(String[] args) {
  	if (args.length < 1) {
  		System.out.println("fuck you no file");
  		return;
  	}
  	BFParser parser = new BFParser();
  	parser.Read(args[0]);

	try {
		parser.Parse();
	} catch (Exception e) {
		System.out.println("you should kys... NOW");
		e.printStackTrace();
	}
 
    System.out.println("aye ebin");
    parser.Execute();
  }
}
