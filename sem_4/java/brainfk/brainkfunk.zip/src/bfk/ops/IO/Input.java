package bfk.ops.IO;

import bfk.BFContext;
import bfk.BaseOp;

public class Input implements BaseOp {
	public void Execute(BFContext ctx) {

	}
}