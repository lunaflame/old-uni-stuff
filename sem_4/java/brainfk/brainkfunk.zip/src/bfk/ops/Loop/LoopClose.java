package bfk.ops.Loop;

import bfk.BFContext;
import bfk.BaseOp;

public class LoopClose implements BaseOp {
	public void Execute(BFContext ctx) {

	}
}