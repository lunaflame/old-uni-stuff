package bfk;

import java.util.ArrayList;


public class BFContext {
	public BFContext() {
		
	}
	
	public void ExecuteOps() {
		if (ops == null) {
			throw new IllegalArgumentException("No ops to run");
		}
		
		dataIdx = 0;
		opIdx = 0;
		
		data.clear();
		data.ensureCapacity(defaultCap);

		for (int i = 0; i < defaultCap; i++) {
			data.add( (byte)0 );
		}
		data.trimToSize();
		
		for (; opIdx < ops.size(); opIdx++) {
			BaseOp op = ops.get(opIdx);
			System.out.println("Executing " + op.getClass().getName());
			op.Execute(this);
		}
	}
	
	// i could do a weird locking mechanism but EHHHH
	public void SetOps(ArrayList<BaseOp> newOps) { ops = newOps; }
	public byte GetByte() { return data.get(dataIdx); }
	
	// questionable
	private void assertByte() {
		if (data.size() <= dataIdx) {
			for (int i = 0; i < (dataIdx - data.size() + 1); i++) {
				data.add((byte)0);
			}
		}
	}
	public void IncrByte() {
		assertByte();
		data.set( dataIdx, (byte)(data.get(dataIdx) + 1) );
	}
	public void DecrByte() {
		assertByte();
		data.set( dataIdx, (byte)(data.get(dataIdx) - 1) );
		}
	
	public void IncrPtr() { dataIdx++; }
	public void DecrPtr() {
		if (dataIdx == 0) {
			throw new IllegalStateException("Brainfunk doesn't specify what should happen once you " +
					"move past the left memory tape edge, so screw you jerk heres an exception");
		}
		
		dataIdx--;
	}

	private int dataIdx = 0;
	private int opIdx = 0;
	private int defaultCap = 65536; 

	private ArrayList<Byte> data = new ArrayList<Byte> (defaultCap);
	private ArrayList<BaseOp> ops = null;
}
