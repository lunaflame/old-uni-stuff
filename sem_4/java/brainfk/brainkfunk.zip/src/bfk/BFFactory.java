package bfk;

import bfk.BaseOp;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Enumeration;
import java.util.HashMap;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Properties;

public class BFFactory {
	public static void SetConfigPath(String fp) {
		cfgPath = fp;
	}

	public static BFFactory Get() {
		if (instance == null) {
			instance = new BFFactory();
		}
		
		return instance;
	}
	
	public boolean CodeHasOp(char code) {
		return GetOpByCode(code) != null;
	}
	
	/**
	 * @param code
	 * @return
	 */
	public BaseOp GetOpByCode(char code) {
		var op = charToOp.get(code);
		if (op == null) {
			op = loadNewOp(code);
		}
		return op;
	}
	
	private BFFactory() {
		charToOp = new HashMap<Character, BaseOp> (256);
		charToOpName = new Properties();
		missingOps = new HashMap<Character, Boolean> (256);
		readObjectFile(cfgPath);
	}
	
	/**
	 * Reads the factory config file containing conversions
	 * code in the input file <-> operation class
	 * 
	 * @param filePath - path to the factory config file
	 */
	private void readObjectFile(String filePath) {
		try {
			InputStream inStr = this.getClass().getClassLoader().getResourceAsStream(filePath);
			
			if (inStr == null) {
				throw new IOException("getResourceAsStream gave null for " + filePath);
			}
			charToOpName.load(inStr);
		} catch (IOException ex) {
			System.out.println("Exception while opening the factory config file: ".concat(ex.toString()));
		}
	}

	/**
	 * Creates a new op instance using the data from the factory config file.
	 * 
	 * @param code - character corresponding to the required operation
	 * @return
	 */

	private BaseOp loadNewOp(char code) {
		// we already tried to get this op and failed; just bail

		if (missingOps.containsKey(code)) {
			return null;
		}
	
		String name = charToOpName.getProperty(Character.toString(code));
		if (name == null) {
			System.out.println("!! No name for code " + code);
			missingOps.put(code, true);
			return null;
		}
		
		Class<?> opClass;
		try {
			opClass = Class.forName(name);
		} catch (ClassNotFoundException e) {
			missingOps.put(code, true);
			System.out.println("!! No class for name " + name);
			return null;
		}
		
		BaseOp op = null;
		
		try {
			op = (BaseOp)opClass.newInstance();
			charToOp.put(code, op);
		} catch (Exception ex) {
			System.out.println("!! Failed to instantiate operation: ".concat(name));
			ex.printStackTrace();
		}
	
		return op;
	}
	
	
	private static BFFactory instance = null;
	private static HashMap<Character, BaseOp> charToOp = null;
	private static HashMap<Character, Boolean> missingOps = null;
	private static Properties charToOpName = null;
	private static String cfgPath = "factory.cfg";
}
