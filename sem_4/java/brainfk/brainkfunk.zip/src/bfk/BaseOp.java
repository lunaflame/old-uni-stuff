package bfk;

public interface BaseOp {
	public void Execute(BFContext ctx);
}