package bfk;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.IOException;
import java.util.ArrayList;
import bfk.BaseOp;
import bfk.BFFactory;

public class BFParser {
	public String Read(String filePath) {
		String content = null;

		try {
			content = Files.readString(Paths.get(filePath));
		} catch (IOException ex) {
			// ??
			System.out.println("Exception while opening input code file.");
		}

		bfCode = content;
		return content;
	}
	
	public void Parse() throws Exception {
		if (bfCode == null) {
			throw new IllegalArgumentException();
		}
		
		BFFactory fac = BFFactory.Get();
		ops.clear();

		int n = bfCode.length(); // mfw
		
		for (int i = 0; i < n; i++) {
			char code = bfCode.charAt(i);
			if (!fac.CodeHasOp(code)) {
				continue;
			}
			
			ops.add(fac.GetOpByCode(code));
		}
	}
	
	public void Execute() {
		if (ctx == null) {
			ctx = new BFContext();
		}
		ctx.SetOps(ops);
		ctx.ExecuteOps();
	}
	
	private String bfCode = null;
	private ArrayList<BaseOp> ops = new ArrayList<BaseOp>();
	private BFContext ctx = null; // dont make a context until we need it
}
