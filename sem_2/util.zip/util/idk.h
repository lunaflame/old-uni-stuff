#ifndef idk_IG
#define idk_IG

#include "dynarr.h"
#include "asalloc.h"
#include "hashtable.h"
#include "queue.h"

#endif
